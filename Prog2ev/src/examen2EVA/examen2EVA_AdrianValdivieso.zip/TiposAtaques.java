package examen2EVA;
/**
 * Interfaz que ayuda a utilizar los metodos en las distintas
 * clases.
 */
public interface TiposAtaques {
	
	public int ataqueBasico();
	public int ataqueEspecial();
}
